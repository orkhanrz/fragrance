﻿import Favorite from '../utils/favorite.js';

Favorite.render();
