﻿import Fragrance from '../utils/fragrance.js';

Fragrance.fetch({ limit: 4 });